from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def home(request):
    return HttpResponse("Welcome to my first app.")
def description(request):
    return HttpResponse("This is the application developed by Nikilesh the ceo of techniks company")
from django.db import models
from datetime import datetime
# Create your models here.
class marks(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=20, null=False)
    DBMS = models.IntegerField()
    DS = models.IntegerField()
    ASE = models.IntegerField()
    CTSD = models.IntegerField(default="0")
    PFSD = models.IntegerField(default="0")
    MATHS = models.IntegerField(default="0")
    ENGLISH = models.IntegerField(default="0")
    dateofexamination = models.DateTimeField(default=datetime.now())
    def __str__(self):
        return self.name
from django.urls import path
from .views import home,description
urlpatterns = [
    path("",home,name="home"),
    path("description/",description,name="description"),
]

from django.shortcuts import render
from django.http import HttpResponse
from demoapp.models import marks

def login(request):
    return render(request, "login.html")
def facebooklogin(request):
    return render(request, "facebooklogin.html")
def twitterlogin(request):
    return render(request, "twitterlogin.html")
def home(request):
    return render(request,"main.html")
def main(request):
    return HttpResponse("This is a project created on django")
def dupmain(request):
    nikki = marks.objects.all()
    return render(request,"dupmain.html",{"nikki":nikki})
